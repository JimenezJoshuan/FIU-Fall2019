/**************************************************************           
Purpose/Description: MoveAllNegative          
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/

import java.util.Arrays;

public class MoveAllNegative {
    
    public static int[] moveNegative(int[] a) {
        //i is counter, j is first index of new array, k is last index
        int i, j, k;
        int[] newArray = new int[a.length];
        j = 0;
        k = a.length - 1;
        
        for (i = 0; i < a.length; i++) {
            
            if (a[i] == -1) {
                newArray[k] = -1;
                //Shifts k to left of previosu index for next placement
                k--;
            }
            
            else {
                newArray[j] = a[i];
                //Shifts j to right of previous index for next placement
                j++;
            }
        }
        return newArray;
    }

    public static void main(String[] args) {
        int [] test = new int[] {6, -1, 8, 2, 3, -1, 4, -1, 1};
        System.out.println("Input: " + Arrays.toString(test));
        test = moveNegative(test);
        System.out.println("Output: " + Arrays.toString(test));
    }
    
}