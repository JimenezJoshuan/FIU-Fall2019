/**************************************************************           
Purpose/Description: RadixSort          
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/

import java.util.ArrayList;

public class RadixSort {
    
    public void radixSort(int a[]) {
        //Buckets made
        ArrayList<Integer>[] buckets = new ArrayList[10];
        
        for (int i = 0; i < buckets.length; i++) {
            buckets[i] = new ArrayList<>();
        }
        //Flag denotes when passes are done
        boolean flag = false;
        int temp;
        int divisor = 1;
        
        while (!flag) {
            
            flag = true;
            
            for (int i = 0; i < a.length; i++) {
                temp = a[i] / divisor;
                
                //Case for odd digits
                if (temp % 2 != 0) {
                    System.out.println("Odd digit found. Exiting...");
                    System.exit(0);
                }
                
                temp = (temp % 10);
                
                buckets[temp].add(a[i]);
                
                if (flag && temp > 0) {
                    flag = false;
                }  
            }
        
        int index = 0;
        //Stores bucket elements
        for (int i = 0; i < 10; i = i + 2) {
            for (Integer j : buckets[i]) {
                a[index++] = j;
            }
            //Clears buckets
            buckets[i].clear();
        }
        divisor = (divisor * 10);
        }
    }
    
    public static void main(String[] args) {
        int[] test = new int[] {24, 2, 4, 466, 48, 66, 8, 44};
        RadixSort x = new RadixSort();
        x.radixSort(test);
        for (int i = 0; i < test.length; i++) {
            System.out.print(test[i] + " ");
        }
    }
}
