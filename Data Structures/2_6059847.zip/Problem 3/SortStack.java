/**************************************************************           
Purpose/Description: SortStack           
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/ 
import java.util.Stack;

public class SortStack {
    
    static Stack<Integer> sort(Stack<Integer> s) {
        Stack<Integer> tempStack;
        tempStack = new Stack();
        
        //Continues until original stack is empty
        while(!s.isEmpty()) {
            int tmp = s.peek();
            s.pop();
            
            //Sorts temporary stack
            while(!tempStack.isEmpty() && tempStack.peek() > tmp) {
                s.push(tempStack.peek());
                tempStack.pop();
            }
            tempStack.push(tmp);
        }
        return tempStack;
    }
    
    public static void main(String[] args) {
        Stack<Integer> test = new Stack();
        test.push(9);
        test.push(6);
        test.push(8);
        test.push(5); 
        test.push(4); 
        test.push(11); 
        test.push(4);
        System.out.println(sort(test));
    }
}