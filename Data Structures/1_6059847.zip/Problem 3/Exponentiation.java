/**************************************************************           
Purpose/Description: Exponentiation with Sub-linear Complexity           
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/ 
public class Exponentiation {
    
    public long exponentiation(long x, int n) {
        if (n == 0) {
            return 1;
        }
        
        if (n == 1) {
            return x;
        }
        
        if (n % 2 == 0) {
            return exponentiation(x * x, n/2);
        }
        
        if (n % 2 == 1) {
            return exponentiation (x * x, n/2) * x;
        }
        
        else {
            return -1;
        }
    }
    
    public static void main(String[] args) {
        Exponentiation x = new Exponentiation();
        
        //Change second parameter to test exponentiation
        System.out.println(x.exponentiation(2, 63));
    }
}
