/**************************************************************           
Purpose/Description: Recursive Search          
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/ 
public class RecursiveSearch {
    
    public int terSearch(int A[], int l, int r, int x) {
        int d1;
        d1 = l + (r - l)/3;
        int d2; 
        d2 = d1 + (r - l)/3;
        
        //Base Case 1 (checks if value is in range of min and max value)
        if ((x > A [A.length - 1]) || (x < A [0])) {
            return -1;
        }
        //Base Case 2
        if (A [d1] == x) {
            return d1;
        }
        //Base Case 3
        if (A [d2] == x) {
            return d2;
        }
        //Recursive Calls
        if (x < A [d1]) {
            return terSearch(A, l, d1 - 1, x);
        }
        
        if ((x > A [d1]) && (x < A [d2])){
            return terSearch(A, d1 + 1, d2 - 1, x);
        }
        
        else {
            return terSearch(A, d2 + 1, r, x);
        }

    }
    
    public static void main(String[] args) {
        RecursiveSearch x = new RecursiveSearch();
        
        //Test Array with 15 elements
        int testArray [] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
        
        //Change fourth parameter to search in array
        System.out.println(x.terSearch(testArray, 0, (testArray.length - 1), 14));
    }
}
