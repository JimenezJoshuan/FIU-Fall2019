/**************************************************************           
Purpose/Description: Dominant Element Finder with Linear Complexity           
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/ 
public class LinearComplexity {
    
    public void dominantFinder (int x []) {
        int max;
        max = 0;
        
        //Starts at end of array and goes backwards to check dominance
        for (int i = x.length - 1; i > 0; i--) {
            int check;
            check = x [i];
            
            if (check > max) {
                max = check;
                System.out.print(Integer.toString(check) + ", ");
            }
            
        }
    }
    
    public static void main(String[] args) {
        LinearComplexity x = new LinearComplexity();
        int testArray [] = {16, 17, 4, 3, 5, 2};
        
        x.dominantFinder(testArray);
        
        
    }
}
