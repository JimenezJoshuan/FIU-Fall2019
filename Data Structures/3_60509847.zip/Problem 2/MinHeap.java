/**************************************************************           
Purpose/Description: MinHeap          
Author’s Panther ID: 6059847          
Certification: I hereby certify that this work is my own and 
        none of it is the work of any other person.          
**************************************************************/
public class MinHeap {
    
    public Integer[] heap;
    
    public void replaceKey(Integer oldKey, Integer newKey) {
        boolean check = false;
        for(int i = 0; i < heap.length; i++) {
            if (heap[i] == oldKey) {
                check = true;
                heap[i] = newKey;
                
                for (int j = heap.length/2; j > 0; j--) {
                    percolateDown();
                }
            }
        }
        
        if (!check) {
            System.out.println("Key does not exist. No changes made.");
        }
    }
}
